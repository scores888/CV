package com.chessvision

import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import java.io.File
import android.content.Intent
import android.net.Uri as AndroidUri
import android.provider.Settings
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chessvision.engine.StockfishEngine
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Background = Color(0xFF10151D)
private val Panel = Color(0xFF1B2430)
private val Accent = Color(0xFF65D6A6)
private const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Background, surface = Panel)) {
                ChessVisionScreen()
            }
        }
    }
}

@Composable
private fun ChessVisionScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var preview by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var fen by remember { mutableStateOf(START_FEN) }
    // Manual correction board: tap a square to cycle through piece symbols.
    var boardCells by remember { mutableStateOf(startBoardCells()) }
    var whiteToMove by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("Stockfish готов к локальному анализу после установки движка.") }
    var bestMove by remember { mutableStateOf("—") }
    var evaluation by remember { mutableStateOf("—") }
    var depth by remember { mutableStateOf("—") }
    var pv by remember { mutableStateOf("—") }
    var boardResult by remember { mutableStateOf("Доска ещё не найдена") }
    var detectedBoard by remember { mutableStateOf<BoardDetector.Result?>(null) }
    var cellsPreview by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var busy by remember { mutableStateOf(false) }
    var overlayStatus by remember { mutableStateOf("Плавающее окно выключено") }
    val overlayPermission = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (Settings.canDrawOverlays(context)) {
            context.startService(Intent(context, FloatingOverlayService::class.java).setAction(FloatingOverlayService.ACTION_SHOW))
            overlayStatus = "Плавающее окно включено"
        }
    }

    val screenCapture = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK && result.data != null) {
            val service = Intent(context, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            androidx.core.content.ContextCompat.startForegroundService(context, service)
            status = "Разрешение получено. Теперь можно анализировать экран из плавающего окна."
        } else status = "Захват экрана отменён."
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedUri = uri
        preview = null
        if (uri != null) status = "Скриншот загружен. Автоматическое распознавание доски будет добавлено следующим модулем."
    }
    LaunchedEffect(selectedUri) {
        val uri = selectedUri ?: return@LaunchedEffect
        preview = withContext(Dispatchers.IO) {
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
        }
        if (preview == null) status = "Не удалось открыть изображение."
    }

    fun loadCapturedFrame() {
        scope.launch {
            val file = File(context.cacheDir, "latest_screen.png")
            if (!file.exists()) { status = "Сначала сделай захват экрана."; return@launch }
            val loaded = withContext(Dispatchers.IO) { BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap() }
            if (loaded != null) { preview = loaded; status = "Последний кадр экрана загружен. Проверь, что доска видна полностью." }
            else status = "Не удалось прочитать последний кадр. Повтори захват."
        }
    }

    Surface(Modifier.fillMaxSize(), color = Background) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(18.dp))
            Text("CHESSVISION", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("Offline chess analysis", color = Color.LightGray, fontSize = 13.sp)
            Spacer(Modifier.height(22.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Скриншот позиции", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    if (preview != null) Image(bitmap = preview!!, contentDescription = "Скриншот шахматной позиции", modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp))
                    else Box(Modifier.fillMaxWidth().height(110.dp).background(Color(0xFF273342), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Text("♜  ♞  ♝  ♛  ♚  ♝  ♞  ♜", color = Color(0xFFB9C6D5))
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("Выбрать скриншот") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { loadCapturedFrame() }, modifier = Modifier.fillMaxWidth()) { Text("Показать последний захваченный экран") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        scope.launch {
                            status = "Ищу шахматную доску на изображении…"
                            val bitmap = withContext(Dispatchers.IO) {
                                val captured = File(context.cacheDir, "latest_screen.png")
                                if (captured.exists()) BitmapFactory.decodeFile(captured.absolutePath)
                                else selectedUri?.let { u -> context.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) } }
                            }
                            if (bitmap == null) {
                                boardResult = "Нет изображения. Сначала захвати экран или выбери скриншот."
                                status = boardResult
                            } else {
                                val found = withContext(Dispatchers.Default) { BoardDetector.find(bitmap) }
                                if (found == null) {
                                    detectedBoard = null
                                    boardResult = "Не удалось уверенно найти доску. Попробуй скриншот, где доска видна целиком."
                                } else {
                                    detectedBoard = found
                                    val l = (found.left * 100.0 / found.imageWidth).toInt()
                                    val t = (found.top * 100.0 / found.imageHeight).toInt()
                                    val sz = (found.size * 100.0 / found.imageWidth).toInt()
                                    boardResult = "Доска: слева $l%, сверху $t%, ширина $sz%. Уверенность: ${found.score.toInt()}. Стрелка будет рассчитана для белых снизу."
                                }
                                status = "Первичная проверка области доски завершена."
                                bitmap.recycle()
                            }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Найти доску на изображении") }
                    Text(boardResult, color = Accent, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        scope.launch {
                            status = "Разделяю доску на 64 клетки…"
                            val bitmap = withContext(Dispatchers.IO) {
                                val captured = File(context.cacheDir, "latest_screen.png")
                                if (captured.exists()) BitmapFactory.decodeFile(captured.absolutePath)
                                else selectedUri?.let { u -> context.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) } }
                            }
                            val board = detectedBoard
                            if (bitmap == null || board == null) {
                                status = "Сначала загрузи изображение и найди доску."
                                bitmap?.recycle()
                            } else {
                                val sheet = withContext(Dispatchers.Default) { BoardGridExtractor.makeContactSheet(bitmap, board) }
                                cellsPreview = sheet?.asImageBitmap()
                                status = if (sheet != null) "Готово: доска разделена на 64 клетки. Это диагностическая сетка, фигуры пока не классифицируются." else "Не удалось разделить доску. Повтори поиск доски."
                                bitmap.recycle()
                            }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Разделить доску на 64 клетки") }
                    if (cellsPreview != null) {
                        Spacer(Modifier.height(8.dp))
                        Text("Проверка разметки 8 × 8", color = Color.White, fontWeight = FontWeight.Bold)
                        Image(bitmap = cellsPreview!!, contentDescription = "64 клетки шахматной доски", modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Редактор позиции 8 × 8", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Нажимай на клетку, чтобы менять фигуру: пусто → белые → чёрные → пусто. Это ручная корректировка, не автоматическое распознавание.", color = Color.LightGray, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    for (row in 0 until 8) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            for (col in 0 until 8) {
                                val index = row * 8 + col
                                val light = (row + col) % 2 == 0
                                val symbol = boardCells[index]
                                val glyph = pieceGlyph(symbol)
                                Button(onClick = {
                                    val updated = boardCells.toMutableList()
                                    updated[index] = nextPiece(symbol)
                                    boardCells = updated
                                }, modifier = Modifier.weight(1f).aspectRatio(1f), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = if (light) Color(0xFFD8DDE4) else Color(0xFF64758A), contentColor = if (symbol.isLowerCase()) Color(0xFF111820) else Color(0xFF111820))) {
                                    Text(glyph, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Ход:", color = Color.White)
                        FilterChip(selected = whiteToMove, onClick = { whiteToMove = true }, label = { Text("Белых") })
                        FilterChip(selected = !whiteToMove, onClick = { whiteToMove = false }, label = { Text("Чёрных") })
                    }
                    OutlinedButton(onClick = { boardCells = startBoardCells(); whiteToMove = true }, modifier = Modifier.fillMaxWidth()) { Text("Начальная позиция") }
                    Button(onClick = {
                        fen = buildFen(boardCells, whiteToMove)
                        context.getSharedPreferences(ScreenCaptureService.PREFS, android.content.Context.MODE_PRIVATE)
                            .edit().putString(ScreenCaptureService.PREF_FEN, fen).apply()
                        status = "FEN сохранён. Плавающее окно сможет использовать эту позицию."
                    }, modifier = Modifier.fillMaxWidth()) { Text("Создать и сохранить FEN") }
                    Spacer(Modifier.height(8.dp))
                    Text("FEN позиции", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = fen, onValueChange = { fen = it }, modifier = Modifier.fillMaxWidth(), minLines = 2, textStyle = LocalTextStyle.current.copy(fontSize = 12.sp), label = { Text("Вставь FEN") })
                    Spacer(Modifier.height(10.dp))
                    Button(enabled = !busy, onClick = {
                        scope.launch {
                            busy = true; status = "Stockfish анализирует позицию…"
                            context.getSharedPreferences(ScreenCaptureService.PREFS, android.content.Context.MODE_PRIVATE)
                                .edit().putString(ScreenCaptureService.PREF_FEN, fen).apply()
                            try {
                                val result = StockfishEngine(context).analyze(fen, 14)
                                bestMove = result.bestMove; evaluation = result.evaluation
                                depth = result.depth.toString(); pv = result.principalVariation
                                status = "Анализ завершён локально."
                                if (Settings.canDrawOverlays(context)) {
                                    context.startService(Intent(context, FloatingOverlayService::class.java)
                                        .setAction(FloatingOverlayService.ACTION_UPDATE)
                                        .putExtra(FloatingOverlayService.EXTRA_MOVE, result.bestMove)
                                        .putExtra(FloatingOverlayService.EXTRA_EVAL, result.evaluation)
                                        .putExtra(FloatingOverlayService.EXTRA_BOARD_LEFT, detectedBoard?.let { it.left.toFloat() / it.imageWidth } ?: -1f)
                                        .putExtra(FloatingOverlayService.EXTRA_BOARD_TOP, detectedBoard?.let { it.top.toFloat() / it.imageHeight } ?: -1f)
                                        .putExtra(FloatingOverlayService.EXTRA_BOARD_SIZE, detectedBoard?.let { it.size.toFloat() / it.imageWidth } ?: -1f))
                                }
                            } catch (e: Exception) {
                                status = "Ошибка Stockfish: ${e.message ?: "неизвестная ошибка"}"
                            } finally { busy = false }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Анализирую…" else "Найти лучший ход") }
                    Spacer(Modifier.height(8.dp))
                    Text(status, color = Color(0xFFCFD8E3), fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("Лучший ход: $bestMove", color = Accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Оценка: $evaluation", color = Color.White)
                    Text("Глубина: $depth", color = Color.White)
                    Text("Вариант: $pv", color = Color(0xFFCFD8E3), fontSize = 12.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = {
                        if (Settings.canDrawOverlays(context)) {
                            context.startService(Intent(context, FloatingOverlayService::class.java).setAction(FloatingOverlayService.ACTION_SHOW))
                            overlayStatus = "Плавающее окно включено"
                        } else {
                            overlayPermission.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, AndroidUri.parse("package:${context.packageName}")))
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Включить плавающее окно") }
                    OutlinedButton(onClick = {
                        screenCapture.launch((context.getSystemService(android.content.Context.MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager).createScreenCaptureIntent())
                    }, modifier = Modifier.fillMaxWidth()) { Text("Разрешить захват экрана") }
                    OutlinedButton(onClick = {
                        context.stopService(Intent(context, FloatingOverlayService::class.java))
                        overlayStatus = "Плавающее окно выключено"
                    }, modifier = Modifier.fillMaxWidth()) { Text("Выключить плавающее окно") }
                    Text(overlayStatus, color = Color.LightGray, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("ChessVision 0.3.7 · анализ из плавающего окна", color = Color.Gray, fontSize = 11.sp)
            Spacer(Modifier.height(20.dp))
        }
    }
}


private fun startBoardCells(): List<Char> = (
    "rnbqkbnr" + "pppppppp" + "........" + "........" +
    "........" + "........" + "PPPPPPPP" + "RNBQKBNR"
).toList()

private fun nextPiece(current: Char): Char {
    val cycle = ".PNBRQKpnbrqk"
    val index = cycle.indexOf(current)
    return cycle[(index + 1).mod(cycle.length)]
}

private fun pieceGlyph(piece: Char): String = when (piece) {
    'K' -> "♔"; 'Q' -> "♕"; 'R' -> "♖"; 'B' -> "♗"; 'N' -> "♘"; 'P' -> "♙"
    'k' -> "♚"; 'q' -> "♛"; 'r' -> "♜"; 'b' -> "♝"; 'n' -> "♞"; 'p' -> "♟"
    else -> " "
}

private fun buildFen(cells: List<Char>, whiteToMove: Boolean): String {
    require(cells.size == 64) { "На доске должно быть 64 клетки" }
    val rows = (0 until 8).map { row ->
        val out = StringBuilder(); var empty = 0
        for (col in 0 until 8) {
            val piece = cells[row * 8 + col]
            if (piece == '.') empty++ else {
                if (empty > 0) { out.append(empty); empty = 0 }
                out.append(piece)
            }
        }
        if (empty > 0) out.append(empty)
        out.toString()
    }
    return rows.joinToString("/") + if (whiteToMove) " w - - 0 1" else " b - - 0 1"
}
