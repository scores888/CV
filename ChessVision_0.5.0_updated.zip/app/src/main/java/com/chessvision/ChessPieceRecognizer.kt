package com.chessvision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.RectF
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.max
import kotlin.math.min

/**
 * YOLOv8 TFLite detector. Model classes are documented by NAKSTStudio:
 * 0 board, 1..6 white K/Q/R/B/N/P, 7..12 black K/Q/R/B/N/P.
 */
class ChessPieceRecognizer(context: Context) : AutoCloseable {
    data class Recognition(
        val fen: String,
        val boardLeft: Float,
        val boardTop: Float,
        val boardSize: Float,
        val pieceCount: Int,
        val confidence: Float
    )
    private data class Detection(val cls: Int, val score: Float, val box: RectF)
    private val interpreter: Interpreter

    init {
        val input = context.assets.openFd("chess_pieces.tflite").use { file ->
            FileInputStream(file.fileDescriptor).use { stream ->
                stream.channel.map(FileChannel.MapMode.READ_ONLY, file.startOffset, file.declaredLength)
            }
        }
        interpreter = Interpreter(input, Interpreter.Options().apply { setNumThreads(3) })
    }

    fun recognize(bitmap: Bitmap): Recognition {
        val inputSize = 640
        val scale = min(inputSize.toFloat() / bitmap.width, inputSize.toFloat() / bitmap.height)
        val scaledW = (bitmap.width * scale).toInt().coerceAtLeast(1)
        val scaledH = (bitmap.height * scale).toInt().coerceAtLeast(1)
        val padX = (inputSize - scaledW) / 2
        val padY = (inputSize - scaledH) / 2
        val inputBmp = Bitmap.createBitmap(inputSize, inputSize, Bitmap.Config.ARGB_8888)
        Canvas(inputBmp).apply {
            drawColor(Color.rgb(114, 114, 114))
            val resized = Bitmap.createScaledBitmap(bitmap, scaledW, scaledH, true)
            drawBitmap(resized, padX.toFloat(), padY.toFloat(), null)
            if (resized !== bitmap) resized.recycle()
        }
        val input = ByteBuffer.allocateDirect(1 * inputSize * inputSize * 3 * 4).order(ByteOrder.nativeOrder())
        for (y in 0 until inputSize) for (x in 0 until inputSize) {
            val p = inputBmp.getPixel(x, y)
            input.putFloat(Color.red(p) / 255f)
            input.putFloat(Color.green(p) / 255f)
            input.putFloat(Color.blue(p) / 255f)
        }
        inputBmp.recycle()
        input.rewind()

        val shape = interpreter.getOutputTensor(0).shape()
        val output = Array(1) { Array(shape[1]) { FloatArray(shape[2]) } }
        interpreter.run(input, output)
        val rows: List<FloatArray> = if (shape[1] <= 32 && shape[2] > shape[1]) {
            (0 until shape[2]).map { i -> FloatArray(shape[1]) { c -> output[0][c][i] } }
        } else {
            output[0].toList()
        }
        val detections = ArrayList<Detection>()
        for (row in rows) {
            if (row.size < 17) continue
            var bestClass = -1
            var bestScore = 0f
            for (c in 4 until min(row.size, 17)) {
                if (row[c] > bestScore) { bestScore = row[c]; bestClass = c - 4 }
            }
            if (bestClass !in 0..12 || bestScore < if (bestClass == 0) 0.28f else 0.35f) continue
            var cx = row[0]; var cy = row[1]; var w = row[2]; var h = row[3]
            // Standard YOLOv8 export uses 640-pixel xywh coordinates. Accommodate normalized outputs too.
            if (max(max(cx, cy), max(w, h)) <= 2f) { cx *= 640f; cy *= 640f; w *= 640f; h *= 640f }
            val l = (cx - w / 2f - padX) / scale
            val t = (cy - h / 2f - padY) / scale
            val r = (cx + w / 2f - padX) / scale
            val b = (cy + h / 2f - padY) / scale
            detections.add(Detection(bestClass, bestScore, RectF(l, t, r, b)))
        }
        val filtered = nms(detections)
        val board = filtered.filter { it.cls == 0 }.maxByOrNull { it.score }
            ?: throw IllegalStateException("Модель не обнаружила шахматную доску")
        val rect = RectF(
            board.box.left.coerceIn(0f, bitmap.width.toFloat()),
            board.box.top.coerceIn(0f, bitmap.height.toFloat()),
            board.box.right.coerceIn(0f, bitmap.width.toFloat()),
            board.box.bottom.coerceIn(0f, bitmap.height.toFloat())
        )
        val boardSize = min(rect.width(), rect.height())
        if (boardSize < 160f) throw IllegalStateException("Доска слишком мала или обнаружена неверно")
        // Board detector box can include a few pixels around the squares; use a centered square.
        val left = (rect.centerX() - boardSize / 2f).coerceAtLeast(0f)
        val top = (rect.centerY() - boardSize / 2f).coerceAtLeast(0f)
        val squares = arrayOfNulls<Char>(64)
        val squareScores = FloatArray(64)
        var pieceCount = 0
        for (d in filtered) {
            if (d.cls !in 1..12) continue
            val cx = d.box.centerX()
            val cy = d.box.centerY()
            val col = ((cx - left) / boardSize * 8).toInt()
            val row = ((cy - top) / boardSize * 8).toInt()
            if (col !in 0..7 || row !in 0..7) continue
            val idx = row * 8 + col
            if (d.score > squareScores[idx]) {
                squareScores[idx] = d.score
                squares[idx] = when (d.cls) {
                    1 -> 'K'; 2 -> 'Q'; 3 -> 'R'; 4 -> 'B'; 5 -> 'N'; 6 -> 'P'
                    7 -> 'k'; 8 -> 'q'; 9 -> 'r'; 10 -> 'b'; 11 -> 'n'; else -> 'p'
                }
            }
        }
        for (p in squares) if (p != null) pieceCount++
        if (pieceCount < 2) throw IllegalStateException("Распознано слишком мало фигур ($pieceCount)")
        val rowsFen = (0 until 8).joinToString("/") { r ->
            buildString {
                var empty = 0
                for (c in 0 until 8) {
                    val p = squares[r * 8 + c]
                    if (p == null) empty++ else {
                        if (empty > 0) { append(empty); empty = 0 }
                        append(p)
                    }
                }
                if (empty > 0) append(empty)
            }
        }
        // Turn, castling and en-passant cannot be recovered reliably from a single screenshot.
        // Explicitly use a provisional white-to-move FEN; UI warns the user about this limitation.
        return Recognition("$rowsFen w - - 0 1", left, top, boardSize, pieceCount, board.score)
    }

    private fun nms(input: List<Detection>): List<Detection> {
        val result = ArrayList<Detection>()
        for (cls in 0..12) {
            val sorted = input.filter { it.cls == cls }.sortedByDescending { it.score }.toMutableList()
            while (sorted.isNotEmpty()) {
                val top = sorted.removeAt(0)
                result.add(top)
                sorted.removeAll { iou(top.box, it.box) > 0.45f }
            }
        }
        return result
    }
    private fun iou(a: RectF, b: RectF): Float {
        val l = max(a.left, b.left); val t = max(a.top, b.top)
        val r = min(a.right, b.right); val bot = min(a.bottom, b.bottom)
        val inter = max(0f, r - l) * max(0f, bot - t)
        val union = a.width() * a.height() + b.width() * b.height() - inter
        return if (union <= 0f) 0f else inter / union
    }
    override fun close() { interpreter.close() }
}
