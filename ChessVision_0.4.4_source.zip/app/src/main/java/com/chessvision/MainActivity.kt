package com.chessvision

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Bg = Color(0xFF0D131B)
private val Panel = Color(0xFF192330)
private val Mint = Color(0xFF65D6A6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Mint, background = Bg, surface = Panel)) { SetupScreen() } }
    }
}

@Composable
private fun SetupScreen() {
    val context = LocalContext.current
    var overlayGranted by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var captureGranted by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Сначала включи два разрешения — потом запускай шахматы.") }
    val overlayLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        overlayGranted = Settings.canDrawOverlays(context)
        status = if (overlayGranted) "Разрешение окна включено" else "Разрешение не выдано"
    }
    val captureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK && result.data != null) {
            val service = Intent(context, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(context, service)
            captureGranted = true
            status = "Захват активен. Теперь открой шахматную игру."
        } else status = "Доступ к экрану не разрешён"
    }
    Surface(Modifier.fillMaxSize(), color = Bg) {
        Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("CHESSVISION", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text("Лучший ход поверх шахматной доски", color = Color(0xFF9EACBC), fontSize = 13.sp)
            Spacer(Modifier.height(28.dp))
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Text("Быстрый запуск", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    PermissionLine("Плавающее окно", overlayGranted)
                    OutlinedButton(onClick = { overlayLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (overlayGranted) "Настроить окно" else "Разрешить окно")
                    }
                    HorizontalDivider(color = Color(0xFF354252))
                    PermissionLine("Захват экрана", captureGranted)
                    Button(onClick = {
                        val manager = context.getSystemService(android.content.Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        captureLauncher.launch(manager.createScreenCaptureIntent())
                    }, modifier = Modifier.fillMaxWidth(), enabled = overlayGranted) {
                        Text(if (captureGranted) "Обновить доступ к экрану" else "Разрешить захват экрана")
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Button(onClick = {
                if (!Settings.canDrawOverlays(context)) status = "Сначала разреши плавающее окно"
                else if (!captureGranted) status = "Сначала разреши захват экрана"
                else {
                    context.startService(Intent(context, FloatingOverlayService::class.java).setAction(FloatingOverlayService.ACTION_SHOW))
                    status = "Окно запущено. Перейди в шахматы и нажми «Найти лучший ход»."
                }
            }, modifier = Modifier.fillMaxWidth().height(52.dp), enabled = overlayGranted && captureGranted, shape = RoundedCornerShape(14.dp)) {
                Text("Запустить ChessVision", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(16.dp))
            Text(status, color = Mint, fontSize = 12.sp)
            Spacer(Modifier.height(18.dp))
            Text("В игре нажми одну кнопку. ChessVision распознает позицию, запустит Stockfish и нарисует стрелку поверх доски.", color = Color(0xFF8493A5), fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

@Composable
private fun PermissionLine(label: String, granted: Boolean) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 14.sp)
        Spacer(Modifier.weight(1f))
        Text(if (granted) "Включено" else "Не включено", color = if (granted) Mint else Color(0xFFFFC56B), fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
