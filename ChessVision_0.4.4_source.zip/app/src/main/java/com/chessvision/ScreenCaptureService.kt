package com.chessvision

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import com.chessvision.engine.StockfishEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/** Keeps the user-approved projection alive; the floating panel requests frames on demand. */
class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.chessvision.START_CAPTURE"
        const val ACTION_CAPTURE = "com.chessvision.CAPTURE_NOW"
        const val ACTION_STOP = "com.chessvision.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val PREFS = "chessvision_settings"
        const val PREF_FEN = "saved_fen"
        private const val CHANNEL = "chessvision_capture"
        private const val NOTIFICATION_ID = 31
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val captureRequested = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var frameWidth = 0
    private var frameHeight = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startProjection(intent)
            ACTION_CAPTURE -> {
                if (projection == null) sendOverlayStatus("Сначала разреши захват экрана в приложении")
                else {
                    captureRequested.set(true)
                    sendOverlayStatus("Снимок запрошен…")
                }
            }
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startProjection(intent: Intent) {
        if (projection != null) return
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("ChessVision активен")
            .setContentText("Нажми «Найти лучший ход» в плавающем окне")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIFICATION_ID, notification)

        val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
        if (code != Activity.RESULT_OK || data == null) { sendOverlayStatus("Разрешение на захват не получено"); stopSelf(); return }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            val metrics = resources.displayMetrics
            frameWidth = metrics.widthPixels
            frameHeight = metrics.heightPixels
            thread = HandlerThread("ChessVisionCapture").also { it.start() }
            handler = Handler(thread!!.looper)
            reader = ImageReader.newInstance(frameWidth, frameHeight, PixelFormat.RGBA_8888, 3)
            reader!!.setOnImageAvailableListener({ source ->
                val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    if (!captureRequested.compareAndSet(true, false)) return@setOnImageAvailableListener
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * frameWidth
                    val padded = Bitmap.createBitmap(frameWidth + rowPadding / pixelStride, frameHeight, Bitmap.Config.ARGB_8888)
                    padded.copyPixelsFromBuffer(buffer)
                    val bitmap = Bitmap.createBitmap(padded, 0, 0, frameWidth, frameHeight)
                    padded.recycle()
                    processFrame(bitmap)
                } catch (e: Exception) {
                    captureRequested.set(false)
                    sendOverlayStatus("Ошибка снимка: ${e.message ?: "неизвестная ошибка"}")
                } finally { image.close() }
            }, handler)
            display = projection!!.createVirtualDisplay("ChessVisionLive", frameWidth, frameHeight, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
            sendOverlayStatus("Готово. Нажми «Найти лучший ход» в плавающем окне.")
        } catch (e: Exception) {
            sendOverlayStatus("Не удалось запустить захват: ${e.message ?: "ошибка"}")
            stopSelf()
        }
    }

    private fun processFrame(bitmap: Bitmap) {
        val file = File(cacheDir, "latest_screen.png")
        try { FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) } }
        catch (e: Exception) { bitmap.recycle(); sendOverlayStatus("Не удалось сохранить кадр"); return }

        sendOverlayStatus("Распознаю фигуры на доске…")
        val recognition = try {
            ChessPieceRecognizer(this).use { it.recognize(bitmap) }
        } catch (e: Exception) {
            bitmap.recycle()
            sendOverlayStatus("Ошибка распознавания: ${e.message ?: "модель"}")
            return
        }
        bitmap.recycle()
        val fen = recognition.fen
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_FEN, fen).apply()
        sendOverlayStatus("Позиция распознана. Stockfish анализирует…")
        scope.launch {
            try {
                val result = StockfishEngine(this@ScreenCaptureService).analyze(fen, 14)
                val update = Intent(this@ScreenCaptureService, FloatingOverlayService::class.java)
                    .setAction(FloatingOverlayService.ACTION_UPDATE)
                    .putExtra(FloatingOverlayService.EXTRA_MOVE, result.bestMove)
                    .putExtra(FloatingOverlayService.EXTRA_EVAL, result.evaluation)
                    .putExtra(FloatingOverlayService.EXTRA_BOARD_LEFT, recognition.boardLeft)
                    .putExtra(FloatingOverlayService.EXTRA_BOARD_TOP, recognition.boardTop)
                    .putExtra(FloatingOverlayService.EXTRA_BOARD_SIZE, recognition.boardSize)
                startService(update)
                sendOverlayStatus("Готово · ${result.bestMove} · глубина ${result.depth}")
            } catch (e: Exception) {
                sendOverlayStatus("Ошибка анализа: ${e.message ?: "Stockfish"}")
            }
        }
    }

    private fun sendOverlayStatus(message: String) {
        try { startService(Intent(this, FloatingOverlayService::class.java).setAction(FloatingOverlayService.ACTION_CAPTURE_STATUS).putExtra(FloatingOverlayService.EXTRA_STATUS, message)) }
        catch (_: Exception) { }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "ChessVision screen capture", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        scope.cancel()
        try { display?.release() } catch (_: Exception) { }
        try { projection?.stop() } catch (_: Exception) { }
        try { reader?.close() } catch (_: Exception) { }
        try { thread?.quitSafely() } catch (_: Exception) { }
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
