package com.chessvision

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.max

/** Crops the detected board into 64 square tiles and builds a labelled contact sheet.
 * This is a diagnostic stage: it does not claim to identify chess pieces yet.
 */
object BoardGridExtractor {
    fun makeContactSheet(source: Bitmap, board: BoardDetector.Result): Bitmap? {
        if (board.left < 0 || board.top < 0 || board.size <= 0) return null
        if (board.left + board.size > source.width || board.top + board.size > source.height) return null
        val tile = 112
        val gap = 3
        val outputSize = tile * 8 + gap * 9
        val output = Bitmap.createBitmap(outputSize, outputSize, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        canvas.drawColor(Color.rgb(20, 26, 35))
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 17f
            setShadowLayer(3f, 1f, 1f, Color.BLACK)
        }
        for (row in 0 until 8) {
            for (col in 0 until 8) {
                val left = board.left + col * board.size / 8
                val top = board.top + row * board.size / 8
                val right = board.left + (col + 1) * board.size / 8
                val bottom = board.top + (row + 1) * board.size / 8
                val cell = Bitmap.createBitmap(source, left, top, max(1, right - left), max(1, bottom - top))
                val scaled = Bitmap.createScaledBitmap(cell, tile, tile, true)
                val dstX = gap + col * (tile + gap)
                val dstY = gap + row * (tile + gap)
                canvas.drawBitmap(scaled, dstX.toFloat(), dstY.toFloat(), null)
                canvas.drawText("${'a' + col}${8 - row}", dstX + 5f, dstY + 19f, labelPaint)
                if (scaled !== cell) scaled.recycle()
                cell.recycle()
            }
        }
        return output
    }
}
