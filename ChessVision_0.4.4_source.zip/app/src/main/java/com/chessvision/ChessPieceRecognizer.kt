package com.chessvision

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.max
import kotlin.math.min

/** YOLOv8 TFLite decoder for NAKSTStudio's 13-class chess detector. */
class ChessPieceRecognizer(context: Context) : java.io.Closeable {
    companion object { private const val INPUT = 640; private const val MODEL = "chess_pieces.tflite" }
    data class Detection(val cls: Int, val x: Float, val y: Float, val w: Float, val h: Float, val score: Float)
    data class Recognition(val fen: String, val boardLeft: Float, val boardTop: Float, val boardSize: Float)
    private val interpreter: Interpreter
    init {
        val file = java.io.File(context.filesDir, MODEL)
        if (!file.exists()) context.assets.open(MODEL).use { input -> file.outputStream().use { input.copyTo(it) } }
        val options = Interpreter.Options().apply { setNumThreads(3) }
        interpreter = Interpreter(file, options)
    }

    fun recognize(bitmap: Bitmap): Recognition {
        val scale = min(INPUT.toFloat() / bitmap.width, INPUT.toFloat() / bitmap.height)
        val rw = (bitmap.width * scale).toInt().coerceAtLeast(1)
        val rh = (bitmap.height * scale).toInt().coerceAtLeast(1)
        val resized = Bitmap.createScaledBitmap(bitmap, rw, rh, true)
        val padX = (INPUT - rw) / 2
        val padY = (INPUT - rh) / 2
        val inputBitmap = Bitmap.createBitmap(INPUT, INPUT, Bitmap.Config.ARGB_8888)
        android.graphics.Canvas(inputBitmap).apply {
            drawColor(android.graphics.Color.BLACK)
            drawBitmap(resized, padX.toFloat(), padY.toFloat(), null)
        }
        val pixels = IntArray(INPUT * INPUT)
        inputBitmap.getPixels(pixels, 0, INPUT, 0, 0, INPUT, INPUT)
        val input = ByteBuffer.allocateDirect(4 * INPUT * INPUT * 3).order(ByteOrder.nativeOrder())
        for (p in pixels) { input.putFloat(((p shr 16) and 255) / 255f); input.putFloat(((p shr 8) and 255) / 255f); input.putFloat((p and 255) / 255f) }
        val shape = interpreter.getOutputTensor(0).shape()
        val output = Array(shape[0]) { Array(shape[1]) { FloatArray(shape[2]) } }
        interpreter.run(input, output)
        val detections = decode(output[0], shape)
        resized.recycle(); inputBitmap.recycle()
        val board = detections.filter { it.cls == 0 }.maxByOrNull { it.score }
            ?: throw IllegalStateException("Модель не нашла шахматную доску")
        // Convert model-space letterboxed coordinates back to the original screen frame.
        val leftModel = board.x - board.w / 2f
        val topModel = board.y - board.h / 2f
        val boardWModel = board.w.coerceAtLeast(1f)
        val boardHModel = board.h.coerceAtLeast(1f)
        val left = ((leftModel - padX) / scale).coerceIn(0f, bitmap.width.toFloat())
        val top = ((topModel - padY) / scale).coerceIn(0f, bitmap.height.toFloat())
        val boardW = (boardWModel / scale).coerceAtMost(bitmap.width.toFloat() - left)
        val boardH = (boardHModel / scale).coerceAtMost(bitmap.height.toFloat() - top)
        if (boardW <= 0f || boardH <= 0f) throw IllegalStateException("Некорректные границы доски")
        // Keep piece coordinates in model space for square assignment.
        val gridLeft = leftModel
        val gridTop = topModel
        val gridW = boardWModel
        val gridH = boardHModel
        val pieces = detections.filter { it.cls in 1..12 && it.score >= 0.30f }
        // A detector can emit several overlapping boxes for one square. Keep only
        // the highest-confidence class for each cell instead of letting the last
        // arbitrary detection overwrite the piece.
        val bestByCell = arrayOfNulls<Detection>(64)
        for (d in pieces) {
            if (d.x < gridLeft || d.x >= gridLeft + gridW || d.y < gridTop || d.y >= gridTop + gridH) continue
            val col = (((d.x - gridLeft) / gridW) * 8f).toInt()
            val row = (((d.y - gridTop) / gridH) * 8f).toInt()
            if (row !in 0..7 || col !in 0..7) continue
            val index = row * 8 + col
            if (bestByCell[index] == null || d.score > bestByCell[index]!!.score) bestByCell[index] = d
        }
        val cells = CharArray(64) { '1' }
        for (index in bestByCell.indices) {
            val d = bestByCell[index] ?: continue
            cells[index] = when (d.cls) { 1 -> 'K'; 2 -> 'Q'; 3 -> 'R'; 4 -> 'B'; 5 -> 'N'; 6 -> 'P'; 7 -> 'k'; 8 -> 'q'; 9 -> 'r'; 10 -> 'b'; 11 -> 'n'; 12 -> 'p'; else -> '1' }
        }
        val fenRows = (0 until 8).joinToString("/") { r ->
            val row = StringBuilder(); var empty = 0
            for (c in 0 until 8) { val v = cells[r * 8 + c]; if (v == '1') empty++ else { if (empty > 0) { row.append(empty); empty = 0 }; row.append(v) } }
            if (empty > 0) row.append(empty); row.toString()
        }
        val count = cells.count { it != '1' }
        if (count < 2) throw IllegalStateException("Распознано слишком мало фигур ($count). Проверь видимость доски.")
        val whiteKings = cells.count { it == 'K' }
        val blackKings = cells.count { it == 'k' }
        if (whiteKings != 1 || blackKings != 1) {
    val rawCounts = (0..12).joinToString(", ") { cls ->
        "$cls=${pieces.count { it.cls == cls }}"
    }
    val cellCounts = (1..12).joinToString(", ") { cls ->
        "$cls=${cells.count { cell ->
            val expected = when (cls) {
                1 -> 'K'; 2 -> 'Q'; 3 -> 'R'
                4 -> 'B'; 5 -> 'N'; 6 -> 'P'
                7 -> 'k'; 8 -> 'q'; 9 -> 'r'
                10 -> 'b'; 11 -> 'n'; 12 -> 'p'
                else -> '1'
            }
            cell == expected
        }}"
    }
    throw IllegalStateException(
        "Короли: белых=$whiteKings, чёрных=$blackKings. " +
        "Объекты: $rawCounts. Клетки: $cellCounts"
    )
}
        }
        if (count > 32) throw IllegalStateException("Распознано $count фигур — больше максимума в шахматах. Повтори захват.")
        // Side-to-move and castling rights are not visible reliably in piece boxes.
        // Do not silently claim those fields are known; this build still defaults to White.
        val squareSize = minOf(boardW, boardH)
        return Recognition("$fenRows w - - 0 1", left / bitmap.width, top / bitmap.height, squareSize / bitmap.width)
    }

    private fun decode(out: Array<FloatArray>, shape: IntArray): List<Detection> {
        val channelsFirst = shape.size == 3 && shape[1] < shape[2]
        val channels = if (channelsFirst) shape[1] else shape[2]
        val count = if (channelsFirst) shape[2] else shape[1]
        if (channels < 17) throw IllegalStateException("Неожиданный формат выхода модели: ${shape.contentToString()}")
        fun v(ch: Int, i: Int): Float = if (channelsFirst) out[ch][i] else out[i][ch]
        val result = ArrayList<Detection>()
        for (i in 0 until count) {
            var cls = -1; var conf = 0f
            for (c in 0 until 13) { val s = v(4 + c, i); if (s > conf) { conf = s; cls = c } }
            if (conf < 0.25f || cls < 0) continue
            result.add(Detection(cls, v(0, i), v(1, i), v(2, i), v(3, i), conf))
        }
        return result
    }
    override fun close() { interpreter.close() }
}
