
package com.chessvision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import org.tensorflow.lite.Interpreter
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

class ChessPieceRecognizer(context: Context) : java.io.Closeable {

    companion object {
        private const val INPUT = 640
        private const val MODEL = "chess_pieces.tflite"

        private const val PIECE_THRESHOLD = 0.18f
        private const val BOARD_THRESHOLD = 0.12f
        private const val NMS_THRESHOLD = 0.45f
    }

    data class Detection(
        val cls: Int,
        val x: Float,
        val y: Float,
        val w: Float,
        val h: Float,
        val score: Float
    )

    data class Recognition(
        val fen: String,
        val boardLeft: Float,
        val boardTop: Float,
        val boardSize: Float
    )

    private val interpreter: Interpreter

    init {
        val file = File(context.filesDir, MODEL)

        if (!file.exists()) {
            context.assets.open(MODEL).use { input ->
                file.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
        }

        val options = Interpreter.Options().apply {
            setNumThreads(3)
        }

        interpreter = Interpreter(file, options)
    }

    fun recognize(bitmap: Bitmap): Recognition {
        require(!bitmap.isRecycled) {
            "Изображение уже освобождено"
        }

        val scale = min(
            INPUT.toFloat() / bitmap.width,
            INPUT.toFloat() / bitmap.height
        )

        val resizedWidth =
            (bitmap.width * scale).toInt().coerceAtLeast(1)

        val resizedHeight =
            (bitmap.height * scale).toInt().coerceAtLeast(1)

        val resized = Bitmap.createScaledBitmap(
            bitmap,
            resizedWidth,
            resizedHeight,
            true
        )

        val padX = (INPUT - resizedWidth) / 2
        val padY = (INPUT - resizedHeight) / 2

        val inputBitmap = Bitmap.createBitmap(
            INPUT,
            INPUT,
            Bitmap.Config.ARGB_8888
        )

        try {
            Canvas(inputBitmap).apply {
                drawColor(Color.BLACK)
                drawBitmap(
                    resized,
                    padX.toFloat(),
                    padY.toFloat(),
                    Paint(Paint.FILTER_BITMAP_FLAG)
                )
            }

            val pixels = IntArray(INPUT * INPUT)

            inputBitmap.getPixels(
                pixels,
                0,
                INPUT,
                0,
                0,
                INPUT,
                INPUT
            )

            val input = ByteBuffer.allocateDirect(
                4 * INPUT * INPUT * 3
            ).order(ByteOrder.nativeOrder())

            for (pixel in pixels) {
                input.putFloat(((pixel shr 16) and 255) / 255f)
                input.putFloat(((pixel shr 8) and 255) / 255f)
                input.putFloat((pixel and 255) / 255f)
            }

            input.rewind()

            val tensor = interpreter.getOutputTensor(0)
            val shape = tensor.shape()

            if (
                shape.size != 3 ||
                shape[0] != 1
            ) {
                throw IllegalStateException(
                    "Неожиданный формат модели: ${shape.contentToString()}"
                )
            }

            val output = Array(shape[0]) {
                Array(shape[1]) {
                    FloatArray(shape[2])
                }
            }

            interpreter.run(input, output)

            val detections = decode(output[0], shape)

            val board = detections
                .filter {
                    it.cls == 0 && it.score >= BOARD_THRESHOLD
                }
                .maxByOrNull { it.score }
                ?: throw IllegalStateException(
                    "Доска не найдена. Убедись, что она полностью видна."
                )

            val boardLeftModel = board.x - board.w / 2f
            val boardTopModel = board.y - board.h / 2f

            val boardWidthModel = board.w
            val boardHeightModel = board.h

            if (
                boardWidthModel <= 0f ||
                boardHeightModel <= 0f
            ) {
                throw IllegalStateException(
                    "Модель определила неправильные границы доски"
                )
            }

            val left = (
                (boardLeftModel - padX) / scale
            ).coerceIn(0f, bitmap.width.toFloat())

            val top = (
                (boardTopModel - padY) / scale
            ).coerceIn(0f, bitmap.height.toFloat())

            val boardWidth = (
                boardWidthModel / scale
            ).coerceAtMost(bitmap.width - left)

            val boardHeight = (
                boardHeightModel / scale
            ).coerceAtMost(bitmap.height - top)

            if (boardWidth <= 0f || boardHeight <= 0f) {
                throw IllegalStateException(
                    "Некорректные координаты доски"
                )
            }

            val pieces = detections.filter {
                it.cls in 1..12 &&
                    it.score >= PIECE_THRESHOLD
            }

            val insideBoard = pieces.filter {
                it.x >= boardLeftModel &&
                    it.x < boardLeftModel + boardWidthModel &&
                    it.y >= boardTopModel &&
                    it.y < boardTopModel + boardHeightModel
            }

            val bestByCell = arrayOfNulls<Detection>(64)

            for (detection in insideBoard) {
                val col = (
                    (detection.x - boardLeftModel) /
                        boardWidthModel * 8f
                    ).toInt()

                val row = (
                    (detection.y - boardTopModel) /
                        boardHeightModel * 8f
                    ).toInt()

                if (row !in 0..7 || col !in 0..7) {
                    continue
                }

                val index = row * 8 + col
                val previous = bestByCell[index]

                if (
                    previous == null ||
                    detection.score > previous.score
                ) {
                    bestByCell[index] = detection
                }
            }

            val cells = CharArray(64) { '1' }

            for (index in bestByCell.indices) {
                val detection = bestByCell[index] ?: continue

                cells[index] = classToPiece(detection.cls)
            }

            val count = cells.count { it != '1' }
            val whiteKings = cells.count { it == 'K' }
            val blackKings = cells.count { it == 'k' }

            if (count < 2 || whiteKings != 1 || blackKings != 1) {
                val rawCounts = (0..12).joinToString(", ") { cls ->
                    val threshold =
                        if (cls == 0) BOARD_THRESHOLD else PIECE_THRESHOLD

                    "$cls=${
                        detections.count {
                            it.cls == cls && it.score >= threshold
                        }
                    }"
                }

                val insideCounts = (1..12).joinToString(", ") { cls ->
                    "$cls=${
                        insideBoard.count { it.cls == cls }
                    }"
                }

                val cellCounts = (1..12).joinToString(", ") { cls ->
                    val piece = classToPiece(cls)
                    "$cls=${cells.count { it == piece }}"
                }

                throw IllegalStateException(
                    "Фигуры распознаны неправильно.\n" +
                        "На доске: $count\n" +
                        "Короли: белых=$whiteKings, чёрных=$blackKings\n" +
                        "Все объекты: $rawCounts\n" +
                        "Внутри доски: $insideCounts\n" +
                        "По клеткам: $cellCounts"
                )
            }

            if (count > 32) {
                throw IllegalStateException(
                    "Обнаружено $count фигур. Повтори захват экрана."
                )
            }

            val fenRows = (0 until 8).joinToString("/") { rowIndex ->
                val row = StringBuilder()
                var empty = 0

                for (col in 0 until 8) {
                    val piece = cells[rowIndex * 8 + col]

                    if (piece == '1') {
                        empty++
                    } else {
                        if (empty > 0) {
                            row.append(empty)
                            empty = 0
                        }

                        row.append(piece)
                    }
                }

                if (empty > 0) {
                    row.append(empty)
                }

                row.toString()
            }

            return Recognition(
                fen = "$fenRows w - - 0 1",
                boardLeft = left / bitmap.width,
                boardTop = top / bitmap.height,
                boardSize = min(boardWidth, boardHeight) / bitmap.width
            )

        } finally {
            if (!resized.isRecycled) {
                resized.recycle()
            }

            if (!inputBitmap.isRecycled) {
                inputBitmap.recycle()
            }
        }
    }

    private fun classToPiece(cls: Int): Char {
        return when (cls) {
            1 -> 'K'
            2 -> 'Q'
            3 -> 'R'
            4 -> 'B'
            5 -> 'N'
            6 -> 'P'
            7 -> 'k'
            8 -> 'q'
            9 -> 'r'
            10 -> 'b'
            11 -> 'n'
            12 -> 'p'
            else -> '1'
        }
    }

    private fun decode(
        out: Array<FloatArray>,
        shape: IntArray
    ): List<Detection> {

        val channelsFirst = shape[1] < shape[2]

        val channels = if (channelsFirst) {
            shape[1]
        } else {
            shape[2]
        }

        val count = if (channelsFirst) {
            shape[2]
        } else {
            shape[1]
        }

        if (channels != 17) {
            throw IllegalStateException(
                "Ожидалось 17 каналов (4 координаты + 13 классов), " +
                    "получено $channels. Форма: ${shape.contentToString()}"
            )
        }

        fun value(channel: Int, index: Int): Float {
            return if (channelsFirst) {
                out[channel][index]
            } else {
                out[index][channel]
            }
        }

        val candidates = ArrayList<Detection>()

        for (i in 0 until count) {
            var bestClass = -1
            var bestScore = 0f

            for (cls in 0 until 13) {
                val score = value(4 + cls, i)

                if (score > bestScore) {
                    bestScore = score
                    bestClass = cls
                }
            }

            val threshold =
                if (bestClass == 0) BOARD_THRESHOLD
                else PIECE_THRESHOLD

            if (bestClass < 0 || bestScore < threshold) {
                continue
            }

            var x = value(0, i)
            var y = value(1, i)
            var w = value(2, i)
            var h = value(3, i)

            // Some exports provide normalized coordinates.
            if (
                x <= 1.5f &&
                y <= 1.5f &&
                w <= 1.5f &&
                h <= 1.5f
            ) {
                x *= INPUT
                y *= INPUT
                w *= INPUT
                h *= INPUT
            }

            if (
                !x.isFinite() ||
                !y.isFinite() ||
                !w.isFinite() ||
                !h.isFinite() ||
                w <= 0f ||
                h <= 0f
            ) {
                continue
            }

            candidates.add(
                Detection(
                    cls = bestClass,
                    x = x,
                    y = y,
                    w = w,
                    h = h,
                    score = bestScore
                )
            )
        }

        return applyNms(candidates)
    }

    private fun applyNms(
        detections: List<Detection>
    ): List<Detection> {

        val result = ArrayList<Detection>()

        for (cls in 0..12) {
            val sorted = detections
                .filter { it.cls == cls }
                .sortedByDescending { it.score }
                .toMutableList()

            while (sorted.isNotEmpty()) {
                val best = sorted.removeAt(0)
                result.add(best)

                val iterator = sorted.iterator()

                while (iterator.hasNext()) {
                    val candidate = iterator.next()

                    if (iou(best, candidate) > NMS_THRESHOLD) {
                        iterator.remove()
                    }
                }
            }
        }

        return result
    }

    private fun iou(
        a: Detection,
        b: Detection
    ): Float {

        val leftA = a.x - a.w / 2f
        val topA = a.y - a.h / 2f
        val rightA = a.x + a.w / 2f
        val bottomA = a.y + a.h / 2f

        val leftB = b.x - b.w / 2f
        val topB = b.y - b.h / 2f
        val rightB = b.x + b.w / 2f
        val bottomB = b.y + b.h / 2f

        val intersectionWidth = max(
            0f,
            min(rightA, rightB) - max(leftA, leftB)
        )

        val intersectionHeight = max(
            0f,
            min(bottomA, bottomB) - max(topA, topB)
        )

        val intersection =
            intersectionWidth * intersectionHeight

        val areaA = a.w * a.h
        val areaB = b.w * b.h

        val union = areaA + areaB - intersection

        return if (union <= 0f) 0f else intersection / union
    }

    override fun close() {
        interpreter.close()
    }
}

