package com.chessvision

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Lightweight first-pass 8x8 checkerboard locator. It locates the board only; it does not identify pieces. */
object BoardDetector {
    data class Result(val left: Int, val top: Int, val size: Int, val score: Double, val imageWidth: Int, val imageHeight: Int)

    fun find(bitmap: Bitmap): Result? {
        val w = bitmap.width
        val h = bitmap.height
        val limit = min(w, h)
        if (limit < 160) return null
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        fun lum(x: Int, y: Int): Double {
            val c = pixels[y * w + x]
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            return (0.299 * r + 0.587 * g + 0.114 * b)
        }
        var best: Result? = null
        val minSize = max(160, limit * 35 / 100)
        val maxSize = limit * 98 / 100
        val sizeStep = max(16, limit / 20)
        val posStep = max(12, limit / 30)
        var size = minSize
        while (size <= maxSize) {
            var y = 0
            while (y + size <= h) {
                var x = 0
                while (x + size <= w) {
                    val means = DoubleArray(64)
                    for (r in 0 until 8) for (c in 0 until 8) {
                        val cx = x + ((c + 0.5) * size / 8.0).toInt()
                        val cy = y + ((r + 0.5) * size / 8.0).toInt()
                        var total = 0.0
                        // Sample a small 3x3 patch around each square center to reduce piece-edge noise.
                        for (dy in -1..1) for (dx in -1..1) {
                            total += lum((cx + dx * max(1, size / 40)).coerceIn(0, w - 1), (cy + dy * max(1, size / 40)).coerceIn(0, h - 1))
                        }
                        means[r * 8 + c] = total / 9.0
                    }
                    var light = 0.0; var dark = 0.0; var lc = 0; var dc = 0
                    var neighborDiff = 0.0; var neighborCount = 0
                    for (r in 0 until 8) for (c in 0 until 8) {
                        val v = means[r * 8 + c]
                        if ((r + c) % 2 == 0) { light += v; lc++ } else { dark += v; dc++ }
                        if (c < 7) { neighborDiff += abs(v - means[r * 8 + c + 1]); neighborCount++ }
                        if (r < 7) { neighborDiff += abs(v - means[(r + 1) * 8 + c]); neighborCount++ }
                    }
                    val contrast = abs(light / lc - dark / dc)
                    val adjacent = neighborDiff / neighborCount
                    val score = contrast * 0.75 + adjacent * 0.25
                    if (best == null || score > best!!.score) best = Result(x, y, size, score, w, h)
                    x += posStep
                }
                y += posStep
            }
            size += sizeStep
        }
        return best?.takeIf { it.score >= 7.0 }
    }
}
