package com.chessvision

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class FloatingOverlayService : Service() {
    companion object {
        const val ACTION_SHOW = "com.chessvision.SHOW_OVERLAY"
        const val ACTION_UPDATE = "com.chessvision.UPDATE_OVERLAY"
        const val EXTRA_MOVE = "move"
        const val EXTRA_EVAL = "eval"
    }

    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var moveText: TextView? = null
    private var evalText: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> showPanel()
            ACTION_UPDATE -> {
                showPanel()
                val move = intent.getStringExtra(EXTRA_MOVE) ?: "—"
                val eval = intent.getStringExtra(EXTRA_EVAL) ?: "—"
                moveText?.text = "➜  Лучший ход: $move"
                evalText?.text = "Оценка: $eval"
            }
        }
        return START_NOT_STICKY
    }

    private fun showPanel() {
        if (panel != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            setBackgroundColor(Color.argb(235, 22, 31, 43))
        }
        val header = TextView(this).apply {
            text = "CHESSVISION   ⋮"
            setTextColor(Color.rgb(101, 214, 166))
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
        }
        moveText = TextView(this).apply {
            text = "➜  Лучший ход: сначала нажми «Найти лучший ход»"
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(0, 12, 0, 4)
        }
        evalText = TextView(this).apply {
            text = "Оценка: —"
            setTextColor(Color.LTGRAY)
            textSize = 13f
        }
        val close = TextView(this).apply {
            text = "Скрыть окно"
            setTextColor(Color.rgb(101, 214, 166))
            textSize = 13f
            setPadding(0, 12, 0, 0)
            setOnClickListener { stopSelf() }
        }
        root.addView(header)
        root.addView(moveText)
        root.addView(evalText)
        root.addView(close)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 110
        }
        try {
            windowManager?.addView(root, params)
            panel = root
        } catch (_: Exception) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        try { panel?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        panel = null
        windowManager = null
        super.onDestroy()
    }
}
