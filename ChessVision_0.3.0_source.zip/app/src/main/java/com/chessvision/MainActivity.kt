package com.chessvision

import android.graphics.BitmapFactory
import android.content.Intent
import android.net.Uri as AndroidUri
import android.provider.Settings
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chessvision.engine.StockfishEngine
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Background = Color(0xFF10151D)
private val Panel = Color(0xFF1B2430)
private val Accent = Color(0xFF65D6A6)
private const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Background, surface = Panel)) {
                ChessVisionScreen()
            }
        }
    }
}

@Composable
private fun ChessVisionScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var preview by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var fen by remember { mutableStateOf(START_FEN) }
    var status by remember { mutableStateOf("Stockfish готов к локальному анализу после установки движка.") }
    var bestMove by remember { mutableStateOf("—") }
    var evaluation by remember { mutableStateOf("—") }
    var depth by remember { mutableStateOf("—") }
    var pv by remember { mutableStateOf("—") }
    var busy by remember { mutableStateOf(false) }
    var overlayStatus by remember { mutableStateOf("Плавающее окно выключено") }
    val overlayPermission = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (Settings.canDrawOverlays(context)) {
            context.startService(Intent(context, FloatingOverlayService::class.java).setAction(FloatingOverlayService.ACTION_SHOW))
            overlayStatus = "Плавающее окно включено"
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedUri = uri
        preview = null
        if (uri != null) status = "Скриншот загружен. Автоматическое распознавание доски будет добавлено следующим модулем."
    }
    LaunchedEffect(selectedUri) {
        val uri = selectedUri ?: return@LaunchedEffect
        preview = withContext(Dispatchers.IO) {
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
        }
        if (preview == null) status = "Не удалось открыть изображение."
    }

    Surface(Modifier.fillMaxSize(), color = Background) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(18.dp))
            Text("CHESSVISION", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("Offline chess analysis", color = Color.LightGray, fontSize = 13.sp)
            Spacer(Modifier.height(22.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Скриншот позиции", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    if (preview != null) Image(bitmap = preview!!, contentDescription = "Скриншот шахматной позиции", modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp))
                    else Box(Modifier.fillMaxWidth().height(110.dp).background(Color(0xFF273342), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Text("♜  ♞  ♝  ♛  ♚  ♝  ♞  ♜", color = Color(0xFFB9C6D5))
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("Выбрать скриншот") }
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("FEN позиции", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = fen, onValueChange = { fen = it }, modifier = Modifier.fillMaxWidth(), minLines = 2, textStyle = LocalTextStyle.current.copy(fontSize = 12.sp), label = { Text("Вставь FEN") })
                    Spacer(Modifier.height(10.dp))
                    Button(enabled = !busy, onClick = {
                        scope.launch {
                            busy = true; status = "Stockfish анализирует позицию…"
                            try {
                                val result = StockfishEngine(context).analyze(fen, 14)
                                bestMove = result.bestMove; evaluation = result.evaluation
                                depth = result.depth.toString(); pv = result.principalVariation
                                status = "Анализ завершён локально."
                                if (Settings.canDrawOverlays(context)) {
                                    context.startService(Intent(context, FloatingOverlayService::class.java)
                                        .setAction(FloatingOverlayService.ACTION_UPDATE)
                                        .putExtra(FloatingOverlayService.EXTRA_MOVE, result.bestMove)
                                        .putExtra(FloatingOverlayService.EXTRA_EVAL, result.evaluation))
                                }
                            } catch (e: Exception) {
                                status = "Ошибка Stockfish: ${e.message ?: "неизвестная ошибка"}"
                            } finally { busy = false }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Анализирую…" else "Найти лучший ход") }
                    Spacer(Modifier.height(8.dp))
                    Text(status, color = Color(0xFFCFD8E3), fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("Лучший ход: $bestMove", color = Accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Оценка: $evaluation", color = Color.White)
                    Text("Глубина: $depth", color = Color.White)
                    Text("Вариант: $pv", color = Color(0xFFCFD8E3), fontSize = 12.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = {
                        if (Settings.canDrawOverlays(context)) {
                            context.startService(Intent(context, FloatingOverlayService::class.java).setAction(FloatingOverlayService.ACTION_SHOW))
                            overlayStatus = "Плавающее окно включено"
                        } else {
                            overlayPermission.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, AndroidUri.parse("package:${context.packageName}")))
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Включить окно поверх Chessis") }
                    OutlinedButton(onClick = {
                        context.stopService(Intent(context, FloatingOverlayService::class.java))
                        overlayStatus = "Плавающее окно выключено"
                    }, modifier = Modifier.fillMaxWidth()) { Text("Скрыть плавающее окно") }
                    Text(overlayStatus, color = Color.LightGray, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("ChessVision 0.3.0 · плавающее окно", color = Color.Gray, fontSize = 11.sp)
            Spacer(Modifier.height(20.dp))
        }
    }
}
