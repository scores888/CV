package com.chessvision.engine

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.TimeUnit

/** Runs the bundled ARM64 Stockfish UCI executable locally. */
class StockfishEngine(private val context: Context) {
    data class Analysis(
        val bestMove: String,
        val evaluation: String,
        val depth: Int,
        val principalVariation: String
    )

    suspend fun analyze(fen: String, depth: Int = 12): Analysis = withContext(Dispatchers.IO) {
        require(fen.trim().split(Regex("\\s+")).size >= 4) { "Некорректная FEN-позиция" }
        val executable = File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")
        check(executable.exists()) {
            "Stockfish не найден в nativeLibraryDir. Проверь, что APK собран с ARM64-библиотекой."
        }
        check(executable.canExecute()) {
            "Android не разрешает запуск Stockfish из nativeLibraryDir."
        }
        val process = try {
            ProcessBuilder(executable.absolutePath)
                .directory(context.filesDir)
                .redirectErrorStream(true)
                .start()
        } catch (e: java.io.IOException) {
            throw IllegalStateException("Не удалось запустить Stockfish (${e.message}). Проверь ARM64-бинарник и упаковку APK.", e)
        }
        try {
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val writer = BufferedWriter(OutputStreamWriter(process.outputStream))
            fun send(command: String) {
                writer.write(command)
                writer.newLine()
                writer.flush()
            }
            fun waitFor(token: String, timeoutSeconds: Long = 12): String {
                val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(timeoutSeconds)
                while (System.nanoTime() < deadline) {
                    if (reader.ready()) {
                        val line = reader.readLine() ?: break
                        if (line.contains(token)) return line
                    } else Thread.sleep(8)
                }
                error("Stockfish не ответил: $token")
            }

            send("uci")
            waitFor("uciok")
            send("setoption name Threads value ${Runtime.getRuntime().availableProcessors().coerceAtMost(2).coerceAtLeast(1)}")
            send("setoption name Hash value 64")
            send("isready")
            waitFor("readyok")
            send("position fen $fen")
            // Prefer a strict time budget for responsive overlay updates.
            send("go movetime 650")

            var score = "Оценка рассчитывается"
            var reachedDepth = 0
            var pv = ""
            var best = ""
            val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(4)
            while (System.nanoTime() < deadline) {
                if (!reader.ready()) {
                    Thread.sleep(8)
                    continue
                }
                val line = reader.readLine() ?: break
                if (line.startsWith("info ")) {
                    val parts = line.split(' ')
                    val d = parts.indexOf("depth")
                    if (d >= 0 && d + 1 < parts.size) reachedDepth = parts[d + 1].toIntOrNull() ?: reachedDepth
                    val cp = parts.indexOf("cp")
                    val mate = parts.indexOf("mate")
                    if (cp >= 0 && cp + 1 < parts.size) {
                        val value = (parts[cp + 1].toDoubleOrNull() ?: 0.0) / 100.0
                        score = if (value > 0) "+%.2f".format(java.util.Locale.US, value) else "%.2f".format(java.util.Locale.US, value)
                    } else if (mate >= 0 && mate + 1 < parts.size) {
                        score = "Мат в ${parts[mate + 1]}"
                    }
                    val p = parts.indexOf("pv")
                    if (p >= 0 && p + 1 < parts.size) pv = parts.drop(p + 1).take(8).joinToString(" ")
                }
                if (line.startsWith("bestmove ")) {
                    best = line.split(' ').getOrNull(1).orEmpty()
                    break
                }
            }
            send("quit")
            check(best.isNotBlank() && best != "(none)") { "Для этой позиции Stockfish не нашёл ход" }
            Analysis(best, score, reachedDepth, pv)
        } finally {
            process.destroy()
            if (!process.waitFor(500, TimeUnit.MILLISECONDS)) process.destroyForcibly()
        }
    }


}
