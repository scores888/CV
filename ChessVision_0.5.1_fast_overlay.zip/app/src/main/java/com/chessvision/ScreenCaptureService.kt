package com.chessvision

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import com.chessvision.engine.StockfishEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/** Periodic screen capture. Projection starts only after explicit system consent. */
class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.chessvision.START_CAPTURE"
        const val ACTION_CAPTURE = "com.chessvision.CAPTURE_NOW"
        const val ACTION_STOP = "com.chessvision.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val PREFS = "chessvision_settings"
        const val PREF_FEN = "saved_fen"
        private const val CHANNEL = "chessvision_capture"
        private const val NOTIFICATION_ID = 31
        private const val SCAN_INTERVAL_MS = 700L
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val captureRequested = AtomicBoolean(false)
    private val processingFrame = AtomicBoolean(false)
    private val analyzing = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var frameWidth = 0
    private var frameHeight = 0
    private var previousCandidate = ""
    private var stableCount = 0
    private var lastAnalyzedPosition = ""
    private var projectionCallback: MediaProjection.Callback? = null

    private val scanRunnable = object : Runnable {
        override fun run() {
            if (projection == null) return
            captureRequested.set(true)
            handler?.postDelayed(this, SCAN_INTERVAL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startProjection(intent)
            ACTION_CAPTURE -> {
                if (projection == null) sendOverlayStatus("Сначала разреши захват экрана в приложении")
                else { captureRequested.set(true); sendOverlayStatus("Проверяю позицию…") }
            }
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startProjection(intent: Intent) {
        if (projection != null) return
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("ChessVision активен")
            .setContentText("Автоматически проверяет шахматную доску")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIFICATION_ID, notification)

        val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
        if (code != Activity.RESULT_OK || data == null) {
            sendOverlayStatus("Разрешение на захват не получено"); stopSelf(); return
        }
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = manager.getMediaProjection(code, data)
            projection = mp
            val metrics = resources.displayMetrics
            frameWidth = metrics.widthPixels
            frameHeight = metrics.heightPixels
            thread = HandlerThread("ChessVisionCapture").also { it.start() }
            handler = Handler(thread!!.looper)
            reader = ImageReader.newInstance(frameWidth, frameHeight, PixelFormat.RGBA_8888, 3)
            reader!!.setOnImageAvailableListener({ source ->
                val image = try { source.acquireLatestImage() } catch (_: Exception) { null } ?: return@setOnImageAvailableListener
                try {
                    if (!captureRequested.compareAndSet(true, false)) return@setOnImageAvailableListener
                    if (!processingFrame.compareAndSet(false, true)) return@setOnImageAvailableListener
                    val plane = image.planes[0]
                    val rowPadding = plane.rowStride - plane.pixelStride * frameWidth
                    val padded = Bitmap.createBitmap(frameWidth + rowPadding / plane.pixelStride, frameHeight, Bitmap.Config.ARGB_8888)
                    padded.copyPixelsFromBuffer(plane.buffer)
                    val bitmap = Bitmap.createBitmap(padded, 0, 0, frameWidth, frameHeight)
                    padded.recycle()
                    scope.launch {
                        try { processFrame(bitmap) }
                        finally { if (!bitmap.isRecycled) bitmap.recycle(); processingFrame.set(false) }
                    }
                } catch (e: Exception) {
                    processingFrame.set(false)
                    captureRequested.set(false)
                    sendOverlayStatus("Ошибка снимка: ${e.message ?: "неизвестная ошибка"}")
                } finally { image.close() }
            }, handler)
            projectionCallback = object : MediaProjection.Callback() {
                override fun onStop() {
                    sendOverlayStatus("Захват экрана остановлен Android")
                    stopSelf()
                }
            }.also { mp.registerCallback(it, handler) }
            display = mp.createVirtualDisplay("ChessVisionLive", frameWidth, frameHeight, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
            handler?.postDelayed(scanRunnable, 250L)
            sendOverlayStatus("Автосканирование включено · проверка каждые 1,35 с")
        } catch (e: Exception) {
            sendOverlayStatus("Не удалось запустить захват: ${e.message ?: "ошибка"}")
            stopSelf()
        }
    }

    private suspend fun processFrame(bitmap: Bitmap) {
        val recognition = try {
            ChessPieceRecognizer(this).use { it.recognize(bitmap) }
        } catch (e: Exception) {
            sendOverlayStatus("Распознавание: ${e.message ?: "ошибка модели"}")
            return
        }
        val position = recognition.fen.substringBefore(' ')
        if (position == previousCandidate) stableCount++ else {
            previousCandidate = position
            stableCount = 1
        }
        if (stableCount < 2) {
            sendOverlayStatus("Проверяю стабильность позиции…")
            return
        }
        if (position == lastAnalyzedPosition) return
        if (!analyzing.compareAndSet(false, true)) return
        lastAnalyzedPosition = position
        val fen = recognition.fen
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_FEN, fen).apply()
        sendOverlayStatus("Позиция распознана (${recognition.pieceCount} фигур). Ход/рокировка не определены; анализ предварительный…")
        try {
            val result = StockfishEngine(this).analyze(fen, 10)
            val update = Intent(this, FloatingOverlayService::class.java)
                .setAction(FloatingOverlayService.ACTION_UPDATE)
                .putExtra(FloatingOverlayService.EXTRA_MOVE, result.bestMove)
                .putExtra(FloatingOverlayService.EXTRA_EVAL, "${result.evaluation} · глубина ${result.depth}")
                .putExtra(FloatingOverlayService.EXTRA_BOARD_LEFT, recognition.boardLeft)
                .putExtra(FloatingOverlayService.EXTRA_BOARD_TOP, recognition.boardTop)
                .putExtra(FloatingOverlayService.EXTRA_BOARD_SIZE, recognition.boardSize)
            startService(update)
            sendOverlayStatus("Готово · ${result.bestMove} · глубина ${result.depth}. Очередь хода неизвестна.")
        } catch (e: Exception) {
            lastAnalyzedPosition = ""
            sendOverlayStatus("Ошибка анализа: ${e.message ?: "Stockfish"}")
        } finally { analyzing.set(false) }
    }

    private fun sendOverlayStatus(message: String) {
        try {
            startService(Intent(this, FloatingOverlayService::class.java)
                .setAction(FloatingOverlayService.ACTION_CAPTURE_STATUS)
                .putExtra(FloatingOverlayService.EXTRA_STATUS, message))
        } catch (_: Exception) { }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "ChessVision screen capture", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler?.removeCallbacksAndMessages(null)
        scanRunnable.let { handler?.removeCallbacks(it) }
        scope.cancel()
        try { projectionCallback?.let { projection?.unregisterCallback(it) } } catch (_: Exception) { }
        try { display?.release() } catch (_: Exception) { }
        try { reader?.setOnImageAvailableListener(null, null); reader?.close() } catch (_: Exception) { }
        try { projection?.stop() } catch (_: Exception) { }
        try { thread?.quitSafely() } catch (_: Exception) { }
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) { }
        super.onDestroy()
    }
}
