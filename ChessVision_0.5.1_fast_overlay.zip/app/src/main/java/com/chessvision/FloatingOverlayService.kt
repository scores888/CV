package com.chessvision

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

class FloatingOverlayService : Service() {

    companion object {
        const val ACTION_SHOW = "com.chessvision.SHOW_OVERLAY"
        const val ACTION_UPDATE = "com.chessvision.UPDATE_OVERLAY"
        const val ACTION_CAPTURE_STATUS = "com.chessvision.CAPTURE_STATUS"

        const val EXTRA_MOVE = "move"
        const val EXTRA_EVAL = "eval"
        const val EXTRA_STATUS = "capture_status"
        const val EXTRA_BOARD_LEFT = "board_left"
        const val EXTRA_BOARD_TOP = "board_top"
        const val EXTRA_BOARD_SIZE = "board_size"
        const val EXTRA_IMAGE_WIDTH = "image_width"
        const val EXTRA_IMAGE_HEIGHT = "image_height"
    }

    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var bubble: TextView? = null
    private var moveText: TextView? = null
    private var evalText: TextView? = null
    private var statusText: TextView? = null
    private var evaluationBar: EvaluationBarView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var arrowView: ArrowOverlayView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {
        showPanel()

        when (intent?.action) {
            ACTION_UPDATE -> {
                moveText?.text =
                    "Лучший ход  ${intent.getStringExtra(EXTRA_MOVE) ?: "—"}"

                val evaluation = intent.getStringExtra(EXTRA_EVAL) ?: "—"
                evalText?.text = "Оценка  $evaluation"
                evaluationBar?.setEvaluation(evaluation)

                val move = intent.getStringExtra(EXTRA_MOVE).orEmpty()
                val left = intent.getFloatExtra(EXTRA_BOARD_LEFT, -1f)
                val top = intent.getFloatExtra(EXTRA_BOARD_TOP, -1f)
                val size = intent.getFloatExtra(EXTRA_BOARD_SIZE, -1f)

                if (
                    move.length >= 4 &&
                    left >= 0f &&
                    top >= 0f &&
                    size > 0f
                ) {
                    showArrow(move, left, top, size)
                    statusText?.text = "Лучший ход показан на доске"
                } else {
                    statusText?.text =
                        "Доска не определена — стрелку не поставить"
                }
            }

            ACTION_CAPTURE_STATUS -> {
                statusText?.text =
                    intent.getStringExtra(EXTRA_STATUS) ?: "Захват экрана…"
            }
        }

        return START_NOT_STICKY
    }

    private fun windowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun rounded(
        color: Int,
        radius: Int
    ): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun showArrow(
        move: String,
        left: Float,
        top: Float,
        size: Float
    ) {
        val wm = windowManager ?: return

        if (arrowView == null) {
            val view = ArrowOverlayView(this)

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                windowType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 0
                y = 0
            }

            try {
                wm.addView(view, params)
                arrowView = view
            } catch (_: Exception) {
                return
            }
        }

        arrowView?.setArrow(move.take(4), left, top, size)
    }

    private class ArrowOverlayView(
        context: android.content.Context
    ) : View(context) {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(40, 235, 130)
            strokeWidth = 11f
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }

        private var fromX = 0f
        private var fromY = 0f
        private var toX = 0f
        private var toY = 0f
        private var visible = false

        fun setArrow(
            move: String,
            left: Float,
            top: Float,
            size: Float
        ) {
            fun squareCenter(
                file: Char,
                rank: Char
            ): Pair<Float, Float> {
                val col = file - 'a'
                val row = '8' - rank

                return Pair(
                    (left + (col + 0.5f) * size / 8f) * width,
                    (top + (row + 0.5f) * size / 8f) * height
                )
            }

            if (
                move.length < 4 ||
                move[0] !in 'a'..'h' ||
                move[2] !in 'a'..'h' ||
                move[1] !in '1'..'8' ||
                move[3] !in '1'..'8'
            ) return

            val a = squareCenter(move[0], move[1])
            val b = squareCenter(move[2], move[3])

            fromX = a.first
            fromY = a.second
            toX = b.first
            toY = b.second

            visible = true
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            if (!visible) return

            paint.color = Color.argb(205, 35, 235, 125)
            paint.strokeWidth =
                (width.coerceAtMost(height) * 0.012f).coerceAtLeast(6f)

            // Soft translucent shaft with a high-contrast arrow head.
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = (width.coerceAtMost(height) * 0.014f).coerceAtLeast(7f)
            paint.color = Color.argb(100, 10, 70, 40)
            canvas.drawLine(fromX, fromY, toX, toY, paint)
            paint.strokeWidth = (width.coerceAtMost(height) * 0.009f).coerceAtLeast(5f)
            paint.color = Color.argb(235, 45, 255, 145)
            canvas.drawLine(fromX, fromY, toX, toY, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(210, 45, 255, 145)
            val marker = (width.coerceAtMost(height) * 0.018f).coerceAtLeast(9f)
            canvas.drawCircle(fromX, fromY, marker, paint)
            canvas.drawCircle(toX, toY, marker * 1.2f, paint)

            val angle = kotlin.math.atan2(
                (toY - fromY).toDouble(),
                (toX - fromX).toDouble()
            ).toFloat()

            val head =
                (width.coerceAtMost(height) * 0.035f).coerceAtLeast(18f)

            val path = Path().apply {
                moveTo(toX, toY)
                lineTo(
                    toX - head * kotlin.math.cos(angle - 0.55f),
                    toY - head * kotlin.math.sin(angle - 0.55f)
                )
                moveTo(toX, toY)
                lineTo(
                    toX - head * kotlin.math.cos(angle + 0.55f),
                    toY - head * kotlin.math.sin(angle + 0.55f)
                )
            }

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = (width.coerceAtMost(height) * 0.009f).coerceAtLeast(5f)
            canvas.drawPath(path, paint)
        }
    }

    private class EvaluationBarView(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var whiteAdvantage = 0f

        fun setEvaluation(text: String) {
            val match = Regex("([+-]?\\d+\\.\\d+)").find(text)
            whiteAdvantage = (match?.groupValues?.getOrNull(1)?.toFloatOrNull() ?: 0f)
                .coerceIn(-8f, 8f) / 8f
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val mid = width / 2f
            paint.color = Color.rgb(64, 72, 83)
            canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), height / 2f, height / 2f, paint)
            val extent = kotlin.math.abs(whiteAdvantage) * width / 2f
            paint.color = if (whiteAdvantage >= 0f) Color.rgb(238, 240, 235) else Color.rgb(45, 49, 57)
            if (whiteAdvantage >= 0f) canvas.drawRect(mid, 0f, mid + extent, height.toFloat(), paint)
            else canvas.drawRect(mid - extent, 0f, mid, height.toFloat(), paint)
            paint.color = Color.rgb(101, 214, 166)
            canvas.drawRect(mid - dp(1), 0f, mid + dp(1), height.toFloat(), paint)
        }

        private fun dp(value: Int) = (value * resources.displayMetrics.density).toFloat()
    }

    private fun showPanel() {
        if (panel != null || bubble != null) return

        windowManager =
            getSystemService(WINDOW_SERVICE) as WindowManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = rounded(Color.argb(172, 20, 28, 39), 16)
            elevation = dp(8).toFloat()
        }

        val header = TextView(this).apply {
            text = "CHESSVISION  ·  Перетащить"
            setTextColor(Color.rgb(101, 214, 166))
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(7))
        }

        moveText = TextView(this).apply {
            text = "Лучший ход  —"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(3), 0, dp(2))
        }

        evalText = TextView(this).apply {
            text = "Оценка  —"
            setTextColor(Color.LTGRAY)
            textSize = 12f
        }

        statusText = TextView(this).apply {
            text = "Готов к анализу"
            setTextColor(Color.rgb(174, 190, 207))
            textSize = 10f
            maxLines = 2
            isSingleLine = false
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextIsSelectable(true)
            setPadding(0, dp(5), 0, dp(8))
        }

        // Исправлено: добавляем statusText напрямую без ScrollView.LayoutParams.
        val statusScroll = ScrollView(this).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = true
            addView(statusText)
        }

        val analyze = TextView(this).apply {
            text = "♟  Найти лучший ход"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(12, 29, 24))
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(Color.rgb(101, 214, 166), 11)

            setOnClickListener {
                try {
                    startService(
                        Intent(
                            this@FloatingOverlayService,
                            ScreenCaptureService::class.java
                        ).setAction(ScreenCaptureService.ACTION_CAPTURE)
                    )

                    statusText?.text = "Захватываю экран и анализирую…"
                } catch (_: Exception) {
                    statusText?.text =
                        "Не удалось начать захват. Открой настройки приложения."
                }
            }
        }

        val collapse = TextView(this).apply {
            text = "Свернуть в кнопку  ↓"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(174, 190, 207))
            textSize = 12f
            setPadding(dp(8), dp(10), dp(8), dp(3))
            setOnClickListener {
                collapsePanel()
            }
        }

        root.addView(header)

        root.addView(
            analyze,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        root.addView(moveText)
        root.addView(evalText)
        evaluationBar = EvaluationBarView(this)
        root.addView(
            evaluationBar,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(9)
            ).apply { topMargin = dp(6); bottomMargin = dp(5) }
        )

        root.addView(
            statusScroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(42)
            )
        )

        root.addView(collapse)

        val params = WindowManager.LayoutParams(
            dp(280),
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(150)
        }

        makeDraggable(header, root, params)

        try {
            windowManager?.addView(root, params)
            panel = root
            layoutParams = params
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun collapsePanel() {
        val wm = windowManager ?: return
        val oldPanel = panel ?: return
        val oldParams = layoutParams

        val small = TextView(this).apply {
            text = "♟"
            gravity = Gravity.CENTER
            textSize = 25f
            setTextColor(Color.rgb(101, 214, 166))
            background = rounded(Color.argb(180, 20, 28, 39), 50)
            elevation = dp(8).toFloat()
        }

        val params = WindowManager.LayoutParams(
            dp(54),
            dp(54),
            windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = oldParams?.x ?: dp(12)
            y = oldParams?.y ?: dp(150)
        }

        makeBubbleDraggable(small, params)

        try {
            wm.removeView(oldPanel)
            panel = null
            layoutParams = null

            wm.addView(small, params)
            bubble = small
            bubbleParams = params
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun expandPanel() {
        val wm = windowManager ?: return
        val oldBubble = bubble ?: return
        val oldParams = bubbleParams

        try {
            wm.removeView(oldBubble)
        } catch (_: Exception) {
        }

        bubble = null
        bubbleParams = null

        showPanel()

        if (oldParams != null) {
            layoutParams?.let {
                it.x = oldParams.x
                it.y = oldParams.y
                try {
                    panel?.let { view ->
                        wm.updateViewLayout(view, it)
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun makeDraggable(
        handle: View,
        target: View,
        params: WindowManager.LayoutParams
    ) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0

        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()

                    try {
                        windowManager?.updateViewLayout(target, params)
                    } catch (_: Exception) {
                    }
                    true
                }

                MotionEvent.ACTION_UP,
                MotionEvent.ACTION_CANCEL -> true

                else -> false
            }
        }
    }

    private fun makeBubbleDraggable(
        view: View,
        params: WindowManager.LayoutParams
    ) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY

                    if (abs(dx) > dp(5) || abs(dy) > dp(5)) {
                        moved = true
                    }

                    params.x = startX + dx.toInt()
                    params.y = startY + dy.toInt()

                    try {
                        windowManager?.updateViewLayout(view, params)
                    } catch (_: Exception) {
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (!moved) expandPanel()
                    true
                }

                MotionEvent.ACTION_CANCEL -> true

                else -> false
            }
        }
    }

    override fun onDestroy() {
        try {
            panel?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {
        }

        try {
            bubble?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {
        }

        try {
            arrowView?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {
        }

        panel = null
        bubble = null
        arrowView = null
        windowManager = null

        super.onDestroy()
    }
}
