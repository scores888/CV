package com.chessvision

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Background = Color(0xFF10151D)
private val Panel = Color(0xFF1B2430)
private val Accent = Color(0xFF65D6A6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent,
                    background = Background,
                    surface = Panel
                )
            ) {
                ChessVisionScreen()
            }
        }
    }
}

@Composable
private fun ChessVisionScreen() {
    val context = LocalContext.current
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var preview by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var status by remember { mutableStateOf("Загрузи скриншот шахматной позиции.") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        selectedUri = uri
        preview = null
        if (uri != null) status = "Изображение выбрано. Подготовка к распознаванию."
    }

    LaunchedEffect(selectedUri) {
        val uri = selectedUri ?: return@LaunchedEffect
        preview = withContext(Dispatchers.IO) {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream)?.asImageBitmap()
            }
        }
        if (preview == null) status = "Не удалось открыть изображение."
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(22.dp))
            Text(
                "CHESSVISION",
                fontSize = 27.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
            Text(
                "Chess position analyzer",
                color = Color.LightGray,
                fontSize = 13.sp
            )
            Spacer(Modifier.height(28.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Позиция", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    if (preview != null) {
                        Image(
                            bitmap = preview!!,
                            contentDescription = "Выбранный скриншот шахматной позиции",
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 420.dp)
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .background(Color(0xFF273342), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "♜  ♞  ♝  ♛  ♚  ♝  ♞  ♜\n\nНЕТ ИЗОБРАЖЕНИЯ",
                                color = Color(0xFFB9C6D5),
                                lineHeight = 28.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = { picker.launch("image/*") },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Выбрать скриншот")
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Panel),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Анализ", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(status, color = Color(0xFFCFD8E3))
                    Spacer(Modifier.height(12.dp))
                    Text("Лучший ход: —", color = Accent, fontSize = 18.sp)
                    Text("Оценка позиции: —", color = Color.White)
                    Text("Глубина: —", color = Color.White)
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = {
                            status = if (selectedUri == null) {
                                "Сначала выбери скриншот."
                            } else {
                                "Распознавание доски ещё не подключено. Это следующий этап разработки."
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = selectedUri != null
                    ) {
                        Text("Подготовить анализ")
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(
                "ChessVision 0.1.0 · локальная обработка",
                color = Color.Gray,
                fontSize = 11.sp
            )
            Spacer(Modifier.height(20.dp))
        }
    }
}
