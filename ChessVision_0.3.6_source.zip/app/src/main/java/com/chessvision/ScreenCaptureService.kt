package com.chessvision

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import java.io.File
import java.io.FileOutputStream

/** Captures one user-approved screen frame for the next board-recognition stage. */
class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.chessvision.START_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL = "chessvision_capture"
        private const val NOTIFICATION_ID = 31
    }
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START) { stopSelf(); return START_NOT_STICKY }
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("ChessVision")
            .setContentText("Захват одного кадра экрана")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIFICATION_ID, notification)
        val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            val metrics = resources.displayMetrics
            thread = HandlerThread("ChessVisionCapture").also { it.start() }
            val handler = Handler(thread!!.looper)
            reader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
            reader!!.setOnImageAvailableListener({ source ->
                val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * metrics.widthPixels
                    val bitmap = Bitmap.createBitmap(metrics.widthPixels + rowPadding / pixelStride, metrics.heightPixels, Bitmap.Config.ARGB_8888)
                    bitmap.copyPixelsFromBuffer(buffer)
                    val cropped = Bitmap.createBitmap(bitmap, 0, 0, metrics.widthPixels, metrics.heightPixels)
                    val file = File(cacheDir, "latest_screen.png")
                    FileOutputStream(file).use { cropped.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    bitmap.recycle(); cropped.recycle()
                    sendOverlayStatus("Кадр сохранён. Автораспознавание доски — следующий этап.")
                } catch (e: Exception) { sendOverlayStatus("Ошибка захвата: ${e.message}") }
                finally { image.close(); stopCapture() }
            }, handler)
            // Give the user a few seconds to switch from ChessVision to Chessis after granting permission.
            sendOverlayStatus("Переключись в Chessis — снимок будет сделан через 4 секунды.")
            handler.postDelayed({
                if (projection != null && reader != null) {
                    display = projection!!.createVirtualDisplay("ChessVisionFrame", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
                }
            }, 4000)
        } catch (e: Exception) { sendOverlayStatus("Не удалось захватить экран: ${e.message}"); stopSelf() }
        return START_NOT_STICKY
    }
    private fun sendOverlayStatus(message: String) {
        startService(Intent(this, FloatingOverlayService::class.java).setAction(FloatingOverlayService.ACTION_CAPTURE_STATUS).putExtra(FloatingOverlayService.EXTRA_STATUS, message))
    }
    private fun stopCapture() { try { display?.release() } catch (_: Exception) {}; display = null; try { projection?.stop() } catch (_: Exception) {}; projection = null; reader?.close(); reader = null; stopSelf() }
    private fun createNotificationChannel() { if (Build.VERSION.SDK_INT >= 26) { val channel = NotificationChannel(CHANNEL, "ChessVision screen capture", NotificationManager.IMPORTANCE_LOW); (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel) } }
    override fun onDestroy() { stopCaptureResources(); super.onDestroy() }
    private fun stopCaptureResources() { try { display?.release() } catch (_: Exception) {}; try { projection?.stop() } catch (_: Exception) {}; try { reader?.close() } catch (_: Exception) {}; thread?.quitSafely() }
}
