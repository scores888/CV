package com.chessvision

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class FloatingOverlayService : Service() {
    companion object {
        const val ACTION_SHOW = "com.chessvision.SHOW_OVERLAY"
        const val ACTION_UPDATE = "com.chessvision.UPDATE_OVERLAY"
        const val ACTION_CAPTURE_STATUS = "com.chessvision.CAPTURE_STATUS"
        const val EXTRA_MOVE = "move"
        const val EXTRA_EVAL = "eval"
        const val EXTRA_STATUS = "capture_status"
        const val EXTRA_BOARD_LEFT = "board_left"
        const val EXTRA_BOARD_TOP = "board_top"
        const val EXTRA_BOARD_SIZE = "board_size"
        const val EXTRA_IMAGE_WIDTH = "image_width"
        const val EXTRA_IMAGE_HEIGHT = "image_height"
    }
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var moveText: TextView? = null
    private var evalText: TextView? = null
    private var statusText: TextView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var arrowView: ArrowOverlayView? = null

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showPanel()
        when (intent?.action) {
            ACTION_UPDATE -> {
                moveText?.text = "➜ Лучший ход: ${intent.getStringExtra(EXTRA_MOVE) ?: "—"}"
                evalText?.text = "Оценка: ${intent.getStringExtra(EXTRA_EVAL) ?: "—"}"
                val move = intent.getStringExtra(EXTRA_MOVE).orEmpty()
                val left = intent.getFloatExtra(EXTRA_BOARD_LEFT, -1f)
                val top = intent.getFloatExtra(EXTRA_BOARD_TOP, -1f)
                val size = intent.getFloatExtra(EXTRA_BOARD_SIZE, -1f)
                if (move.length >= 4 && left >= 0f && top >= 0f && size > 0f) {
                    showArrow(move, left, top, size)
                    statusText?.text = "Стрелка показана (ориентация: белые снизу)"
                } else {
                    statusText?.text = "Для стрелки сначала найди доску на скриншоте"
                }
            }
            ACTION_CAPTURE_STATUS -> statusText?.text = intent.getStringExtra(EXTRA_STATUS) ?: "Захват экрана…"
        }
        return START_NOT_STICKY
    }
    private fun showArrow(move: String, left: Float, top: Float, size: Float) {
        val wm = windowManager ?: return
        if (arrowView == null) {
            val view = ArrowOverlayView(this)
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }
            try { wm.addView(view, params); arrowView = view } catch (_: Exception) { return }
        }
        arrowView?.setArrow(move.take(4), left, top, size)
    }

    private class ArrowOverlayView(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(40, 235, 130); strokeWidth = 11f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private var fromX = 0f; private var fromY = 0f; private var toX = 0f; private var toY = 0f; private var visible = false
        fun setArrow(move: String, left: Float, top: Float, size: Float) {
            fun squareCenter(file: Char, rank: Char): Pair<Float, Float> {
                val col = file - 'a'
                val row = '8' - rank
                return Pair((left + (col + 0.5f) * size / 8f) * width, (top + (row + 0.5f) * size / 8f) * height)
            }
            if (move.length < 4 || move[0] !in 'a'..'h' || move[2] !in 'a'..'h' || move[1] !in '1'..'8' || move[3] !in '1'..'8') return
            val a = squareCenter(move[0], move[1]); val b = squareCenter(move[2], move[3])
            fromX = a.first; fromY = a.second; toX = b.first; toY = b.second; visible = true; invalidate()
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas); if (!visible) return
            paint.color = Color.argb(205, 35, 235, 125); paint.strokeWidth = (width.coerceAtMost(height) * 0.012f).coerceAtLeast(6f)
            canvas.drawLine(fromX, fromY, toX, toY, paint)
            val angle = kotlin.math.atan2((toY-fromY).toDouble(), (toX-fromX).toDouble()).toFloat()
            val head = (width.coerceAtMost(height) * 0.035f).coerceAtLeast(18f)
            val path = Path().apply {
                moveTo(toX, toY)
                lineTo(toX - head * kotlin.math.cos(angle - 0.55f), toY - head * kotlin.math.sin(angle - 0.55f))
                moveTo(toX, toY)
                lineTo(toX - head * kotlin.math.cos(angle + 0.55f), toY - head * kotlin.math.sin(angle + 0.55f))
            }
            canvas.drawPath(path, paint)
        }
    }

    private fun showPanel() {
        if (panel != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 16, 22, 16)
            setBackgroundColor(Color.argb(238, 22, 31, 43))
        }
        val header = TextView(this).apply {
            text = "CHESSVISION  ⋮  перетащи"
            setTextColor(Color.rgb(101, 214, 166)); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
        }
        moveText = TextView(this).apply { text = "➜ Лучший ход: —"; setTextColor(Color.WHITE); textSize = 15f; setPadding(0, 10, 0, 4) }
        evalText = TextView(this).apply { text = "Оценка: —"; setTextColor(Color.LTGRAY); textSize = 13f }
        statusText = TextView(this).apply { text = "Экран ещё не захвачен"; setTextColor(Color.LTGRAY); textSize = 12f; setPadding(0, 5, 0, 0) }
        val close = TextView(this).apply {
            text = "Скрыть окно"; setTextColor(Color.rgb(101, 214, 166)); textSize = 13f; setPadding(0, 10, 0, 0)
            setOnClickListener { stopSelf() }
        }
        root.addView(header); root.addView(moveText); root.addView(evalText); root.addView(statusText); root.addView(close)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 24; y = 180
        }
        // Drag only from the header so the close action remains usable.
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; true }
                MotionEvent.ACTION_MOVE -> { params.x = startX + (event.rawX - downX).toInt(); params.y = startY + (event.rawY - downY).toInt(); try { windowManager?.updateViewLayout(root, params) } catch (_: Exception) {}; true }
                else -> false
            }
        }
        try { windowManager?.addView(root, params); panel = root; layoutParams = params } catch (_: Exception) { stopSelf() }
    }
    override fun onDestroy() {
        try { panel?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        try { arrowView?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        panel = null; arrowView = null; windowManager = null; super.onDestroy()
    }
}
