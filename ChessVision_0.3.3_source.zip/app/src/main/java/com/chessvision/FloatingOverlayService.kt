package com.chessvision

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class FloatingOverlayService : Service() {
    companion object {
        const val ACTION_SHOW = "com.chessvision.SHOW_OVERLAY"
        const val ACTION_UPDATE = "com.chessvision.UPDATE_OVERLAY"
        const val ACTION_CAPTURE_STATUS = "com.chessvision.CAPTURE_STATUS"
        const val EXTRA_MOVE = "move"
        const val EXTRA_EVAL = "eval"
        const val EXTRA_STATUS = "capture_status"
    }
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var moveText: TextView? = null
    private var evalText: TextView? = null
    private var statusText: TextView? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showPanel()
        when (intent?.action) {
            ACTION_UPDATE -> {
                moveText?.text = "➜ Лучший ход: ${intent.getStringExtra(EXTRA_MOVE) ?: "—"}"
                evalText?.text = "Оценка: ${intent.getStringExtra(EXTRA_EVAL) ?: "—"}"
            }
            ACTION_CAPTURE_STATUS -> statusText?.text = intent.getStringExtra(EXTRA_STATUS) ?: "Захват экрана…"
        }
        return START_NOT_STICKY
    }
    private fun showPanel() {
        if (panel != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 16, 22, 16)
            setBackgroundColor(Color.argb(238, 22, 31, 43))
        }
        val header = TextView(this).apply {
            text = "CHESSVISION  ⋮  перетащи"
            setTextColor(Color.rgb(101, 214, 166)); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
        }
        moveText = TextView(this).apply { text = "➜ Лучший ход: —"; setTextColor(Color.WHITE); textSize = 15f; setPadding(0, 10, 0, 4) }
        evalText = TextView(this).apply { text = "Оценка: —"; setTextColor(Color.LTGRAY); textSize = 13f }
        statusText = TextView(this).apply { text = "Экран ещё не захвачен"; setTextColor(Color.LTGRAY); textSize = 12f; setPadding(0, 5, 0, 0) }
        val close = TextView(this).apply {
            text = "Скрыть окно"; setTextColor(Color.rgb(101, 214, 166)); textSize = 13f; setPadding(0, 10, 0, 0)
            setOnClickListener { stopSelf() }
        }
        root.addView(header); root.addView(moveText); root.addView(evalText); root.addView(statusText); root.addView(close)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 24; y = 180
        }
        // Drag only from the header so the close action remains usable.
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; true }
                MotionEvent.ACTION_MOVE -> { params.x = startX + (event.rawX - downX).toInt(); params.y = startY + (event.rawY - downY).toInt(); try { windowManager?.updateViewLayout(root, params) } catch (_: Exception) {}; true }
                else -> false
            }
        }
        try { windowManager?.addView(root, params); panel = root; layoutParams = params } catch (_: Exception) { stopSelf() }
    }
    override fun onDestroy() {
        try { panel?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        panel = null; windowManager = null; super.onDestroy()
    }
}
